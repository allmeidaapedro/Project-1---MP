'''Testando as funções de velha.py'''


import pytest
from velha import horizontal, vertical, principal_diagonal, secondary_diagonal, definitive_winner
from velha import counter, guess_winner, impossible
from velha import tie, tic_tac_toe_checker



@pytest.mark.horizontal
def test_horizontal():
    '''testa loop horizontal da matriz de jogo'''
    matrix = [[0, 0, 0], [1, 1, 2], [2, 2, 1]]
    second_matrix = [[1, 2, 2], [0, 0, 2], [1, 1, 1]]
    third_matrix = [[2, 2, 2], [0, 1, 0], [1, 1, 0]]
    assert horizontal(matrix) is None
    assert horizontal(second_matrix) == 1
    assert horizontal(third_matrix) == 2


@pytest.mark.vertical
def test_vertical():
    '''testa loop vertical da matriz de jogo'''
    matrix = [[0, 1, 2], [0, 1, 1], [0, 0, 2]]
    second_matrix = [[1, 2, 1], [1, 2, 0], [2, 2, 1]]
    third_matrix = [[0, 2, 1], [1, 2, 1], [2, 0, 1]]
    assert vertical(matrix) is None
    assert vertical(second_matrix) == 2
    assert vertical(third_matrix) == 1


@pytest.mark.diagonal
def test_diagonal():
    '''testa loop diagonal na matriz de jogo'''
    matrix = [[1, 2, 2], [0, 1, 1], [2, 1, 1]]
    second_matrix = [[1, 2, 2], [0, 2, 1], [2, 1, 1]]
    assert principal_diagonal(matrix) == 1
    assert secondary_diagonal(second_matrix) == 2


@pytest.mark.counter
def test_counter():
    '''teste da função que conta as jogadas de x e de o'''
    matrix = [[1, 2, 1], [2, 2, 1], [1, 0, 0]]
    assert counter(matrix) == (4, 3)


@pytest.mark.guess_winner
def test_guess_winner():
    '''teste da função que verifica individualmente a vitória de x ou o'''
    matrix = [[1, 1, 0], [2, 2, 2], [1, 1, 1]]
    second_matrix = [[1, 2, 1], [2, 2, 1], [1, 1, 2]]
    assert guess_winner(matrix, 2)
    assert guess_winner(matrix, 1)
    assert not guess_winner(second_matrix, 1)
    assert not guess_winner(second_matrix, 2)


@pytest.mark.definitive_winner
def test_definitive_winner():
    '''teste da função que verifica a vitória ou não de um dos jogadores'''
    matrix = [[1, 2, 2], [0, 0, 2], [1, 1, 1]]
    second_matrix = [[1, 2, 1], [1, 2, 0], [2, 2, 1]]
    third_matrix = [[1, 2, 2], [0, 2, 1], [2, 1, 1]]
    fourth_matrix = [[1, 2, 2], [0, 1, 1], [2, 1, 1]]

    assert definitive_winner(matrix) == 1
    assert definitive_winner(second_matrix) == 2
    assert definitive_winner(third_matrix) == 2
    assert definitive_winner(fourth_matrix) == 1


@pytest.mark.impossible
def test_impossible():
    '''teste da função que valida o jogo'''
    matrix = [[1, 1, 0], [2, 2, 2], [2, 2, 0]]
    second_matrix = [[1, 1, 1], [2, 2, 2], [1, 0, 0]]
    third_matrix = [[1, 1, 1], [1, 0, 0], [2, 2, 0]]
    assert impossible(matrix)
    assert impossible(second_matrix)
    assert impossible(third_matrix)


@pytest.mark.tie
def test_tie():
    '''testar função que indica no jogo um empate ou um jogo indefinido'''
    matrix = [[1, 2, 1], [1, 2, 2], [2, 1, 2]]
    second_matrix = [[1, 0, 2], [1, 2, 2], [0, 1, 0]]
    assert tie(matrix)
    assert not tie(second_matrix)


@pytest.mark.checker
def test_tic_tac_toe_checker():
    '''testar função final que verifica o jogo da velha utilizando as outras funções auxiliares'''
    matrix = [[1, 1, 2], [2, 1, 0], [0, 2, 1]]
    second_matrix = [[1, 2, 1], [1, 1, 0], [2, 2, 2]]
    third_matrix = [[1, 1, 2], [2, 2, 1], [1, 1, 2]]
    fourth_matrix = [[1, 0, 1], [0, 2, 0], [0, 2, 0]]
    fifth_matrix = [[1, 1, 2], [0, 1, 0], [1, 2, 0]]
    sixth_matrix = [[1, 1, 2], [2, 1, 0], [0, 1, 0]]
    assert tic_tac_toe_checker(matrix) == 1
    assert tic_tac_toe_checker(second_matrix) == 2
    assert tic_tac_toe_checker(third_matrix) == 0
    assert tic_tac_toe_checker(fourth_matrix) == -1
    assert tic_tac_toe_checker(fifth_matrix) == -2
    assert tic_tac_toe_checker(sixth_matrix) == -2
