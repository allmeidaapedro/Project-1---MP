'''Código principal'''

import time

def impossible(matrix):
    '''checa se o jogo é inválido/impossível'''
    count_x, count_o = counter(matrix)

    if count_x in (count_o, count_o + 1):
        if guess_winner(matrix, 2):
            if guess_winner(matrix, 1):
                return True
            if count_x == count_o:
                return False
        if guess_winner(matrix, 1) and count_x != count_o + 1:
            return True
        if not guess_winner(matrix, 2):
            return False
    return True


def guess_winner(matrix, guess):
    '''verificação se o ou x foi vencedor individualmente'''
    # horizontal
    for row in matrix:
        count_guess = row.count(guess)
        if count_guess == 3:
            return True

    # vertical
    vertical_matrix = list(map(list, zip(*matrix)))
    for i in range(3):
        count_guess = vertical_matrix.count(guess)
        if count_guess == 3:
            return True

    # diagonais
    count_guess = 0
    for i in range(3):
        if matrix[i][i] == guess:
            count_guess += 1
    if count_guess == 3:
        return True

    count_guess = 0
    for i in range(3):
        for j in range(3):
            if i + j == 2 and matrix[i][j] == guess:
                count_guess += 1
    if count_guess == 3:
        return True

    return False


def counter(matrix):
    '''Função auxiliar que conta as jogadas de x e o'''
    count_x, count_o = 0, 0
    for row in matrix:
        for column in row:
            if column == 1:
                count_x += 1
            elif column == 2:
                count_o += 1
    return count_x, count_o


def horizontal(matrix):
    '''loop horizontal na matriz de jogo'''
    for row in matrix:
        count_x, count_o = 0, 0
        for column in row:
            if column == 1:
                count_x += 1
            elif column == 2:
                count_o += 1
        if count_x == 3:
            return 1
        if count_o == 3:
            return 2


def vertical(matrix):
    '''loop vertical na matriz de jogo'''
    for i in range(3):
        count_x, count_o = 0, 0
        for j in range(3):
            if matrix[j][i] == 1:
                count_x += 1
            elif matrix[j][i] == 2:
                count_o += 1
        if count_x == 3:
            return 1
        if count_o == 3:
            return 2


def principal_diagonal(matrix):
    '''loop na diagonal principal da matriz de jogo'''
    count_x, count_o = 0, 0
    for i in range(3):
        if matrix[i][i] == 1:
            count_x += 1
        elif matrix[i][i] == 2:
            count_o += 1
    if count_x == 3:
        return 1
    if count_o == 3:
        return 2

def secondary_diagonal(matrix):
    '''loop na diagonal secundária na matriz de jogo'''
    count_x, count_o = 0, 0
    for i in range(3):
        for j in range(3):
            if i + j == 2:
                if matrix[i][j] == 1:
                    count_x += 1
                elif matrix[i][j] == 2:
                    count_o += 1

    if count_x == 3:
        return 1
    if count_o == 3:
        return 2


def definitive_winner(matrix, winner=None):
    '''utiliza as funções de loop para determinar o vencedor'''
    if horizontal(matrix):
        winner = horizontal(matrix)
    if vertical(matrix):
        winner = vertical(matrix)
    if principal_diagonal(matrix):
        winner = principal_diagonal(matrix)
    if secondary_diagonal(matrix):
        winner = secondary_diagonal(matrix)

    return winner


def tie(matrix):
    '''verificar empate (0) ou indefinido (-1)'''
    for row in matrix:
        for column in row:
            if column == 0:
                return False
    return True


def tic_tac_toe_checker(matrix):
    '''verificar o jogo da velha'''
    if impossible(matrix):
        return -2
    if definitive_winner(matrix):
        return definitive_winner(matrix)
    if tie(matrix):
        return 0
    return -1


if __name__ == '__main__':
    print(f'{"-" * 10} Bem vindo ao verificador de jogo da velha {"-" * 10}')
    time.sleep(1)
    print(f'{"[0, 0, 0]"}')
    print(f'{"[0, 0, 0]"}')
    print(f'{"[0, 0, 0]"}')
    time.sleep(1)
    while True:
        inp = input('Digite o jogo em uma matriz 3x3 para verificarmos ou "nao" para finalizar: ')
        if inp.lower() == 'nao':
            break
        numbers = [int(x) for x in inp if x.isnumeric()]
        jogo = [[numbers[0], numbers[1], numbers[2]],
                [numbers[3], numbers[4], numbers[5]],
                [numbers[6], numbers[7], numbers[8]]]
        print('Se X ganhou, temos 1')
        print('Se O ganhou, temos 2')
        print('Se houve um empate, temos 0')
        print('Se o jogo está indefinido, temos -1')
        print('Se o jogo representa uma combinação impossível, temos -2')
        time.sleep(1)
        print()
        print('Verificando.....')
        print()
        time.sleep(1)
        print(f'O resultado é: {tic_tac_toe_checker(jogo)}')
        print()
        